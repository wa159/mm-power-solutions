MM POWER SOLUTIONS WEBSITE

Upload index.html and the complete images folder to your GitHub repository.
Keep these filenames exactly:
- yinergy-8kw-5kwh.jpg
- sunpro-sl-6kw.jpg
- solar-panels-installation.jpg
- solar-inverter-battery.jpg

GitHub: wa159/mm-power-solutions
Pages: https://wa159.github.io/mm-power-solutions/
